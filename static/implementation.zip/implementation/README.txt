server main package: ticket
command-line parameters: none
Notes:
    The server runs on port 8080.
    No additional modules are needed to run the server.

client package: com.thefunteam.android
Developed with Pixel C (9.94", API 25)
Notes:
    After installing, the app's human-readable name is "android"
